import express from 'express';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const router = express.Router();
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

router.post('/generate', async (req, res) => {
  const userInput = req.body.prompt;

  try {
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`,
      {
        contents: [{ parts: [{ text: userInput }] }]
      },
      { headers: { 'Content-Type': 'application/json' } }
    );

    const aiReply = response.data.candidates[0].content.parts[0].text;
    res.json({ reply: aiReply });
  } catch (err) {
    console.error("Gemini API error:", err?.response?.data || err.message);
    res.status(500).json({ error: 'Gemini API failed' });
  }
});

export default router;
