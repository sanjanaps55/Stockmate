import express from 'express';
import Analytics from '../models/Analytics.js';

const router = express.Router();

router.get('/:shopId', async (req, res) => {
  try {
    const analytics = await Analytics.findOne({ shopId: req.params.shopId });
    if (!analytics) {
      return res.status(404).json({ message: 'No analytics data found' });
    }
    res.json(analytics);
  } catch (err) {
    console.error('Error fetching analytics:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
