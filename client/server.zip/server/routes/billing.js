import express from 'express';
import InventoryItem from "../models/InventoryItem.js";
import Bill from '../models/Bill.js';

const router = express.Router();

// GET inventory for shop
router.get('/inventory/:shopId', async (req, res) => {
  try {
    const inventory = await InventoryItem.find({ shop: req.params.shopId });
    res.json(inventory);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

// POST new bill and update inventory quantities
router.post('/bill/:shopId', async (req, res) => {
  const { customerName, items, subtotal, tax, discount, total } = req.body;
  const shopId = req.params.shopId;

  try {
    // Update inventory quantities
    for (const item of items) {
      await InventoryItem.findOneAndUpdate(
        { _id: item._id, shop: shopId },
        { $inc: { qty: -item.quantity } }, // Decrease qty
        { new: true }
      );
    }

    // Save bill
    const bill = new Bill({
      customerName,
      items,
      subtotal,
      tax,
      discount,
      total,
      shop: shopId,
      createdAt: new Date()
    });

    await bill.save();
    res.status(201).json({ message: "Bill processed and saved", bill });

  } catch (err) {
    console.error("Billing error:", err);
    res.status(500).json({ error: "Failed to process bill", details: err.message });
  }
});


export default router;
