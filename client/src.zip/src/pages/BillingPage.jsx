import React, { useState, useRef } from 'react';

export default function SupermarketBilling() {
  const [inventory, setInventory] = useState([
    { id: 1, name: 'Fresh Oranges', weight: '500 g', price: 89.75, barcode: '8901234567890' },
    { id: 2, name: 'Red Onion', weight: '1 kg', price: 30.50, barcode: '8901234567891' },
    { id: 3, name: 'Fresh Yellow Lemons', weight: '250 g', price: 55.00, barcode: '8901234567892' },
    { id: 4, name: 'Pomegranate', weight: '250 g', price: 35.25, barcode: '8901234567893' },
    { id: 5, name: 'Toor Dal', weight: '1 kg', price: 120.00, barcode: '8901234567894' },
    { id: 6, name: 'Basmati Rice', weight: '5 kg', price: 350.00, barcode: '8901234567895' },
    { id: 7, name: 'Whole Wheat Bread', weight: '400 g', price: 40.00, barcode: '8901234567896' },
    { id: 8, name: 'Milk', weight: '500 ml', price: 28.00, barcode: '8901234567897' },
  ]);

  const [cart, setCart] = useState([]);
  const [newItem, setNewItem] = useState({ name: '', price: '', quantity: '1', barcode: '' });
  const [couponCode, setCouponCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [customerName, setCustomerName] = useState('');
  const billRef = useRef(null);

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const tax = subtotal * 0.18; // 18% GST
  const total = subtotal + tax - discount;

  // Search products
  const filteredInventory = inventory.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.barcode.includes(searchQuery)
  );

  const handleAddToCart = (product) => {
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
      setCart(cart.map(item => 
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const handleManualItemAdd = (e) => {
    e.preventDefault();
    if (!newItem.name || !newItem.price) return;
    
    const newItemObject = {
      id: Date.now(), // Generate unique ID
      name: newItem.name,
      price: parseFloat(newItem.price),
      quantity: parseInt(newItem.quantity) || 1,
      barcode: newItem.barcode || 'N/A'
    };
    
    setCart([...cart, newItemObject]);
    setNewItem({ name: '', price: '', quantity: '1', barcode: '' });
  };

  const handleQuantityChange = (id, newQuantity) => {
    if (newQuantity < 1) return;
    setCart(cart.map(item => 
      item.id === id ? { ...item, quantity: newQuantity } : item
    ));
  };

  const handleRemoveItem = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const applyCoupon = () => {
    if (couponCode.trim().toLowerCase() === 'grocery10') {
      setDiscount(subtotal * 0.1); // 10% discount
    } else if (couponCode.trim().toLowerCase() === 'grocery20') {
      setDiscount(subtotal * 0.2); // 20% discount
    } else {
      setDiscount(0);
    }
  };

  const clearCart = () => {
    setCart([]);
    setDiscount(0);
    setCouponCode('');
    setCustomerName('');
  };

  const handleBarcodeKeyPress = (e) => {
    if (e.key === 'Enter') {
      const product = inventory.find(item => item.barcode === e.target.value);
      if (product) {
        handleAddToCart(product);
        setSearchQuery('');
      }
    }
  };

  const handlePrintBill = () => {
    const printContent = billRef.current;
    const originalContents = document.body.innerHTML;
    
    document.body.innerHTML = printContent.innerHTML;
    window.print();
    document.body.innerHTML = originalContents;
  };

  const formatDate = () => {
    const date = new Date();
    return date.toLocaleDateString('en-IN') + ' ' + date.toLocaleTimeString('en-IN');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-4">
        <h1 className="text-3xl font-bold text-green-900 mb-6">Supermarket Billing System</h1>
        
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left Column - Item Selection and Addition */}
          <div className="lg:w-2/3">
            {/* Barcode Scanner Simulation */}
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
              <div className="flex">
                <input
                  type="text"
                  placeholder="Search item or scan barcode..."
                  className="flex-grow px-4 py-3 border border-gray-300 rounded-l focus:outline-none focus:ring-1 focus:ring-green-500"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={handleBarcodeKeyPress}
                />
                <button 
                  className="bg-green-900 text-white px-6 py-3 rounded-r hover:bg-green-800"
                >
                  Search
                </button>
              </div>
            </div>
            
            {/* Product Grid */}
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
              <h2 className="text-xl font-semibold mb-4">Select Products</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredInventory.length > 0 ? (
                  filteredInventory.map(product => (
                    <div 
                      key={product.id} 
                      className="border border-gray-200 rounded-lg p-3 flex items-center hover:bg-gray-50 cursor-pointer"
                      onClick={() => handleAddToCart(product)}
                    >
                      <div className="flex-grow">
                        <div className="font-medium">{product.name}</div>
                        <div className="text-sm text-gray-500">{product.weight}</div>
                        <div className="font-semibold text-green-900">₹{product.price.toFixed(2)}</div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="col-span-full text-center py-6 text-gray-500">
                    No products found
                  </div>
                )}
              </div>
            </div>
            

            
            {/* Cart/Current Bill */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <h2 className="text-xl font-semibold p-4 bg-green-900 text-white">Current Bill</h2>
              
              {/* Cart Items */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="py-3 px-4 text-left">Item</th>
                      <th className="py-3 px-4 text-right">Price</th>
                      <th className="py-3 px-4 text-center">Quantity</th>
                      <th className="py-3 px-4 text-right">Subtotal</th>
                      <th className="py-3 px-4 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cart.length > 0 ? (
                      cart.map(item => (
                        <tr key={item.id} className="border-t border-gray-200">
                          <td className="py-3 px-4">
                            <div className="flex items-center">
                              <div>
                                <div className="font-medium">{item.name}</div>
                                {item.weight && <div className="text-xs text-gray-500">{item.weight}</div>}
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right">₹{item.price.toFixed(2)}</td>
                          <td className="py-3 px-4">
                            <div className="flex justify-center">
                              <div className="flex items-center border border-gray-300 rounded">
                                <button 
                                  className="px-2 py-1 text-gray-600 hover:bg-gray-100"
                                  onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                                >
                                  −
                                </button>
                                <span className="px-3 py-1">{item.quantity}</span>
                                <button 
                                  className="px-2 py-1 text-gray-600 hover:bg-gray-100"
                                  onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right font-medium">
                            ₹{(item.price * item.quantity).toFixed(2)}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button 
                              onClick={() => handleRemoveItem(item.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              Remove
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="5" className="py-6 text-center text-gray-500">
                          No items in cart
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              
              {/* Cart Controls */}
              {cart.length > 0 && (
                <div className="p-4 border-t border-gray-200 bg-gray-50">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-grow flex">
                      <input
                        type="text"
                        placeholder="Coupon Code"
                        className="flex-grow px-4 py-2 border border-gray-300 rounded-l focus:outline-none"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                      />
                      <button 
                        className="bg-green-900 text-white px-4 py-2 rounded-r hover:bg-green-800"
                        onClick={applyCoupon}
                      >
                        Apply
                      </button>
                    </div>
                    <button 
                      className="bg-white text-red-600 border border-red-600 px-4 py-2 rounded hover:bg-red-50"
                      onClick={clearCart}
                    >
                      Clear Bill
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Right Column - Final Bill */}
          <div className="lg:w-1/3">
            <div className="bg-white rounded-lg shadow-sm sticky top-4" ref={billRef}>
              {/* Bill Header */}
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-2xl font-bold text-center text-green-900 mb-2">GREEN MART</h2>
                <p className="text-center text-gray-500 text-sm mb-4">123 Market Street, Cityville</p>
                <p className="text-center text-gray-500 text-sm mb-4">Tel: 123-456-7890</p>
                <p className="text-center text-sm mb-2">Invoice #: INV-{Date.now().toString().substring(7)}</p>
                <p className="text-center text-sm mb-2">Date: {formatDate()}</p>
                
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Customer Name</label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-green-500"
                    placeholder="Enter customer name"
                  />
                </div>
              </div>
              
              {/* Bill Items */}
              <div className="p-6">
                <h3 className="font-semibold mb-4">Bill Details</h3>
                
                <div className="border-b border-gray-200 pb-4 mb-4">
                  {cart.length > 0 ? (
                    cart.map((item, index) => (
                      <div key={index} className="flex justify-between mb-2 text-sm">
                        <div>
                          <span>{item.name} × {item.quantity}</span>
                        </div>
                        <span>₹{(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-gray-500 py-4">No items added</div>
                  )}
                </div>
                
                {/* Bill Totals */}
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">GST (18%)</span>
                    <span>₹{tax.toFixed(2)}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Discount</span>
                      <span>-₹{discount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-4 border-t border-gray-200 font-bold text-lg">
                    <span>Total</span>
                    <span>₹{total.toFixed(2)}</span>
                  </div>
                </div>
                
                {/* Print Button (Replacing Bill Note) */}
                <div className="mt-6">
                  <button 
                    className="w-full bg-green-900 text-white py-3 rounded-md hover:bg-green-800 transition disabled:bg-gray-400 disabled:cursor-not-allowed"
                    onClick={handlePrintBill}
                    disabled={cart.length === 0}
                  >
                    Print Bill
                  </button>
                </div>
                
                {/* Footer */}
                <div className="mt-8 border-t border-gray-200 pt-4 text-center text-sm text-gray-500">
                  <p>Thank you for shopping with us!</p>
                  <p>Visit us again</p>
                </div>
              </div>
            </div>
            
            {/* Removed duplicate Print Bill button that was outside the bill container */}
          </div>
        </div>
      </div>
    </div>
  );
}