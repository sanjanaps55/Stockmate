import React, { useState, useEffect } from 'react';
import { useParams } from "react-router-dom";
import { Search, Plus, Calendar, Package, DollarSign, X } from 'lucide-react';

export default function EnhancedInventoryPage() {
  const { shopId } = useParams();
  const [items, setItems] = useState([]);
  const [editingItem, setEditingItem] = useState(null);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    qty: "",
    price: "",
    expiry: ""
  });

  useEffect(() => {
    async function fetchInventory() {
      const token = localStorage.getItem("token");
      try {
        const res = await fetch(`http://localhost:5000/api/inventory/${shopId}`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        const data = await res.json();
        setItems(data);
        console.log("shopId in InventoryPage:", shopId);
      } catch (err) {
        console.error("Failed to fetch inventory:", err);
      }
    }

    if (shopId) fetchInventory();
  }, [shopId]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddItem = async (e) => {
    e.preventDefault();

    if (!formData.name || !formData.qty || !formData.price || !formData.expiry) return;

    const token = localStorage.getItem("token");
    
    if (editingItem) {
      handleUpdateItem(editingItem._id);
      return;
    }

    try {
      const res = await fetch(`http://localhost:5000/api/inventory/${shopId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name: formData.name,
          qty: parseInt(formData.qty),
          price: parseFloat(formData.price),
          expiry: formData.expiry
        })
      });

      const newItem = await res.json();
      setItems(prev => [...prev, newItem].sort((a, b) => a.name.localeCompare(b.name)));
      setFormData({ name: "", qty: "", price: "", expiry: "" });
      setShowForm(false);
    } catch (err) {
      console.error("Error adding item:", err);
    }
  };

  const handleDeleteItem = async (itemId) => {
    const token = localStorage.getItem("token");
    try {
      await fetch(`http://localhost:5000/api/inventory/item/${itemId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      setItems(prev => prev.filter(item => item._id !== itemId));
    } catch (err) {
      console.error("Error deleting item:", err);
    }
  };

  const handleUpdateItem = async (itemId) => {
    const token = localStorage.getItem("token");
    try {
      const res = await fetch(`http://localhost:5000/api/inventory/item/${itemId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name: formData.name,
          qty: parseInt(formData.qty),
          price: parseFloat(formData.price),
          expiry: formData.expiry
        })
      });

      const updatedItem = await res.json();
      setItems(prev =>
        prev.map(item => (item._id === itemId ? updatedItem : item)).sort((a, b) => a.name.localeCompare(b.name))
      );
      setFormData({ name: "", qty: "", price: "", expiry: "" });
      setShowForm(false);
      setEditingItem(null);
    } catch (err) {
      console.error("Error updating item:", err);
    }
  };

  const handleEditClick = (item) => {
    // Format the date for the input field (YYYY-MM-DD format)
    const formattedExpiry = new Date(item.expiry).toISOString().split('T')[0];
    
    setFormData({
      name: item.name,
      qty: item.qty.toString(),
      price: item.price.toString(),
      expiry: formattedExpiry
    });
    setEditingItem(item);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingItem(null);
    setFormData({ name: "", qty: "", price: "", expiry: "" });
  };

  const filteredItems = items.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase())
  ).sort((a, b) => a.name.localeCompare(b.name));

  // Function to format date to a more readable format
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };

  // Function to determine if an item is expiring soon (within 30 days)
  const isExpiringSoon = (dateString) => {
    const expiryDate = new Date(dateString);
    const today = new Date();
    const differenceInTime = expiryDate - today;
    const differenceInDays = differenceInTime / (1000 * 3600 * 24);
    return differenceInDays <= 30 && differenceInDays >= 0;
  };

  return (
    <div className="min-h-screen bg-green-50 text-green-900">
      {/* Header */}
      <div className="bg-green-800 p-4 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <h1 className="text-2xl font-bold text-white">Inventory Management</h1>
          
          {/* Search Bar */}
          <div className="relative w-full md:w-1/3">
            <input
              type="text"
              placeholder="Search items..."
              className="w-full pl-10 pr-4 py-2 rounded-full bg-white text-green-900 focus:outline-none focus:ring-2 focus:ring-green-500"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 text-green-500" size={18} />
          </div>
          
          {/* Add Item Button */}
          <button
            onClick={() => setShowForm(true)}
            className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-full font-medium flex items-center gap-2 transition-colors"
          >
            <Plus size={18} />
            Add Item
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6">
        {/* Count Summary */}
        <div className="mb-6 bg-white rounded-lg shadow p-4">
          <p className="text-green-800">
            Showing {filteredItems.length} of {items.length} items
            {search && ` matching "${search}"`}
          </p>
        </div>

        {/* Grid Layout */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-3">
            {filteredItems.map((item, idx) => {
              const isExpiring = isExpiringSoon(item.expiry);
              return (
                <div 
                  key={idx} 
                  className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className={`p-1 ${isExpiring ? 'bg-yellow-400' : 'bg-green-500'}`}></div>
                  <div className="p-3">
                    <h3 className="text-base font-bold text-green-800 truncate">{item.name}</h3>
                    
                    <div className="flex items-center text-sm text-green-700 mt-2">
                      <Package size={14} className="mr-1 flex-shrink-0" />
                      <span className="truncate">Qty: <strong>{item.qty}</strong></span>
                    </div>
                    
                    <div className="flex items-center text-sm text-green-700 mt-1">
                      <DollarSign size={14} className="mr-1 flex-shrink-0" />
                      <span className="truncate">₹<strong>{item.price}</strong></span>
                    </div>
                    
                    <div className={`flex items-center text-sm mt-1 ${isExpiring ? 'text-yellow-600' : 'text-green-700'}`}>
                      <Calendar size={14} className="mr-1 flex-shrink-0" />
                      <span className="truncate">{formatDate(item.expiry)}</span>
                    </div>
                    
                    {isExpiring && (
                      <p className="mt-1 text-xs text-yellow-600 font-medium">
                        Expiring soon!
                      </p>
                    )}

                    {/* Edit and Delete buttons */}
                    <div className="flex justify-between items-center mt-3 pt-2 border-t border-gray-100">
                      <button
                        className="text-xs text-blue-600 hover:text-blue-800 hover:underline font-medium"
                        onClick={() => handleEditClick(item)}
                      >
                        Edit
                      </button>
                      <button
                        className="text-xs text-red-600 hover:text-red-800 hover:underline font-medium"
                        onClick={() => handleDeleteItem(item._id)}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-xl text-green-800">No items found matching your search.</p>
          </div>
        )}
      </div>

      {/* Modal Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md overflow-hidden">
            <div className="bg-green-800 text-white px-6 py-4 flex justify-between items-center">
              <h2 className="text-xl font-bold">{editingItem ? "Update Item" : "Add New Item"}</h2>
              <button 
                onClick={handleCloseForm}
                className="text-white hover:text-green-200"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-green-800 mb-1">Item Name</label>
                <input
                  type="text"
                  name="name"
                  placeholder="Enter item name"
                  className="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  value={formData.name}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-green-800 mb-1">Quantity</label>
                <input
                  type="number"
                  name="qty"
                  placeholder="Enter quantity"
                  className="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  value={formData.qty}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-green-800 mb-1">Price (₹)</label>
                <input
                  type="number"
                  name="price"
                  placeholder="Enter price"
                  className="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  value={formData.price}
                  onChange={handleInputChange}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-green-800 mb-1">Expiry Date</label>
                <input
                  type="date"
                  name="expiry"
                  className="w-full px-4 py-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  value={formData.expiry}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="pt-4">
                <button
                  onClick={handleAddItem}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded transition-colors"
                >
                  {editingItem ? "Update Item" : "Add Item"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}